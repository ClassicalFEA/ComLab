ComLab (Computational Mechanics Lab or CML), sometimes referred to as "Nast-Core", is no longer officially supported.
It is provided "as is".

The "docs" folder contains the Installation Instructions (environment variables must be defined).

The "docs" folder also contains the Manual and Agreements.